#!/usr/bin/env bash
set -euo pipefail

# Creates or updates an A/CNAME record for givc.brainsait.com in the provided zone.
# Expects CF_API_TOKEN, CF_ZONE_ID, CF_DOMAIN, TARGET_HOST env vars.

if [ -z "${CF_API_TOKEN:-}" ] || [ -z "${CF_ZONE_ID:-}" ] || [ -z "${CF_DOMAIN:-}" ] || [ -z "${TARGET_HOST:-}" ]; then
  echo "Missing required environment variables. Set CF_API_TOKEN, CF_ZONE_ID, CF_DOMAIN, TARGET_HOST"
  exit 1
fi

AUTH_HDR="Authorization: Bearer ${CF_API_TOKEN}"
API="https://api.cloudflare.com/client/v4/zones/${CF_ZONE_ID}/dns_records"

# Try to find existing record (CNAME)
EXISTING=$(curl -sS -X GET "${API}?type=CNAME&name=${CF_DOMAIN}" -H "${AUTH_HDR}" -H "Content-Type: application/json" | jq -r '.result[0].id // empty')

DATA=$(jq -n --arg type "CNAME" --arg name "${CF_DOMAIN}" --arg content "${TARGET_HOST}" --arg ttl "3600" --argjson proxied false '{
  type: $type,
  name: $name,
  content: $content,
  ttl: ($ttl|tonumber),
  proxied: $proxied
}')

if [ -n "$EXISTING" ]; then
  echo "Updating existing DNS record id=$EXISTING -> ${CF_DOMAIN} -> ${TARGET_HOST}"
  curl -sS -X PUT "${API}/${EXISTING}" -H "${AUTH_HDR}" -H "Content-Type: application/json" --data "$DATA" | jq .
else
  echo "Creating DNS record -> ${CF_DOMAIN} -> ${TARGET_HOST}"
  curl -sS -X POST "${API}" -H "${AUTH_HDR}" -H "Content-Type: application/json" --data "$DATA" | jq .
fi